import { Membre } from './membre';

describe('Membre', () => {
  it('should create an instance', () => {
    expect(new Membre()).toBeTruthy();
  });
});
