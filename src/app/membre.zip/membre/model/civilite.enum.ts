export enum Civilite {
  M = "Monsieur",
  MME = "Madame",
  MLLE = "Mademoiselle"
}
